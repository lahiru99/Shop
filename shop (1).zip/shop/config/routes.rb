Rails.application.routes.draw do

  resources :users
  get 'welcome/men', to: 'welcome#men'

  get 'welcome/women', to: 'welcome#women'

  get 'welcome/kids', to: 'welcome#kids'

  get 'welcome/new-ins',  to: 'welcome#new-ins'

  get 'welcome/index'

  root 'welcome#index'
  
  

resources :newsletter
  


  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
