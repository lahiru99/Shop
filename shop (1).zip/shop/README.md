Names = S.M.D.G Sanjula Lahiru Ananda  &  Navneet Sujith
Student_ID = S3737333  &  S3791635

Highest level = Pass Level

Heruko URl: https://infinite-shore-97164.herokuapp.com/

Heruko Deployment Logs: 

2021-05-23T16:32:54.939782+00:00 app[web.1]: [2f4abb7c-f600-4da6-9e66-12e205dd4065] vendor/bundle/ruby/2.6.0/gems/puma-3.12.6/lib/puma/server.rb:706:in `handle_request'
2021-05-23T16:32:54.939782+00:00 app[web.1]: [2f4abb7c-f600-4da6-9e66-12e205dd4065] vendor/bundle/ruby/2.6.0/gems/puma-3.12.6/lib/puma/server.rb:476:in `process_client'
2021-05-23T16:32:54.939783+00:00 app[web.1]: [2f4abb7c-f600-4da6-9e66-12e205dd4065] vendor/bundle/ruby/2.6.0/gems/puma-3.12.6/lib/puma/server.rb:334:in `block in run'
2021-05-23T16:32:54.939783+00:00 app[web.1]: [2f4abb7c-f600-4da6-9e66-12e205dd4065] vendor/bundle/ruby/2.6.0/gems/puma-3.12.6/lib/puma/thread_pool.rb:135:in `block in spawn_thread'
2021-05-23T16:32:54.943806+00:00 heroku[router]: at=info method=GET path="/resource/css/glider.css" host=infinite-shore-97164.herokuapp.com request_id=2f4abb7c-f600-4da6-9e66-12e205dd4065 fwd="59.102.20.142" dyno=web.1 connect=1ms service=13ms status=404 bytes=1902 protocol=https
2021-05-23T16:32:55.335855+00:00 heroku[router]: at=info method=GET path="/resource/image/cc1.jpg" host=infinite-shore-97164.herokuapp.com request_id=ecad77e6-61aa-45ff-9f07-916133156271 fwd="59.102.20.142" dyno=web.1 connect=0ms service=6ms status=200 bytes=14662 protocol=https
2021-05-23T16:32:55.820339+00:00 heroku[router]: at=info method=GET path="/resource/image/cc2.jpg" host=infinite-shore-97164.herokuapp.com request_id=067a8046-6161-4e38-8396-ec2acfba5cf5 fwd="59.102.20.142" dyno=web.1 connect=0ms service=5ms status=200 bytes=17269 protocol=https
2021-05-23T16:32:55.827773+00:00 heroku[router]: at=info method=GET path="/resource/image/cc3.jpg" host=infinite-shore-97164.herokuapp.com request_id=e66e20a5-4421-4007-b9f2-675e9c60a9c9 fwd="59.102.20.142" dyno=web.1 connect=1ms service=6ms status=200 bytes=13432 protocol=https
2021-05-23T16:32:55.858304+00:00 heroku[router]: at=info method=GET path="/resource/image/cc4.jpg" host=infinite-shore-97164.herokuapp.com request_id=a4339187-89db-4a6a-94de-7c4cfba5df5a fwd="59.102.20.142" dyno=web.1 connect=0ms service=2ms status=200 bytes=6194 protocol=https
2021-05-23T16:33:06.584825+00:00 heroku[router]: at=info method=GET path="/favicon.ico" host=infinite-shore-97164.herokuapp.com request_id=bd896412-72a7-49c2-ad57-4d8fd22463d3 fwd="59.102.20.142" dyno=web.1 connect=1ms service=3ms status=200 bytes=143 protocol=https

Bitbucket URL:  https://Navneet555@bitbucket.org/lahiru7675/develop-and-production.git
Bitbucket URL:  https://lahiru7675@bitbucket.org/lahiru7675/develop-and-production.git